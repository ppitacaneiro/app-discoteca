import { Component, OnInit } from '@angular/core';
import { Album } from '../models/album';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-altadisco',
  templateUrl: './altadisco.component.html',
  styleUrls: ['./altadisco.component.css']
})
export class AltadiscoComponent implements OnInit {

  album: Album;
  
  artistName = new FormControl('');
  titleAlbum = new FormControl('');
  datePublished = new FormControl('');
  ressumeForm = new FormControl('');
  infoForm = new FormControl('');
  
  constructor() { 
    this.album = new Album();
  }

  ngOnInit() {
  }

  getValues(): void {

    this.album.artist = this.artistName.value;
    this.album.title = this.titleAlbum.value;
    this.album.published = this.datePublished.value;
    this.album.content = this.ressumeForm.value;
    this.album.summary = this.infoForm.value;

    console.log
    (
      'artist => ' + this.album.artist + 
      'title => ' + this.album.title + 
      'published => ' + this.album.published + 
      'content => ' + this.album.content + 
      'summary => ' + this.album.summary
    );
  }

}
