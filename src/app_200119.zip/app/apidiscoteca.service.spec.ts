import { TestBed, inject } from '@angular/core/testing';

import { ApidiscotecaService } from './apidiscoteca.service';

describe('ApidiscotecaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApidiscotecaService]
    });
  });

  it('should be created', inject([ApidiscotecaService], (service: ApidiscotecaService) => {
    expect(service).toBeTruthy();
  }));
});
