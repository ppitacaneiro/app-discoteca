export class Album {
    artist:string;
    image:string;
    title:string;
    songs: string[];
    content:string;
    published:string;
    summary:string;
}