import { Component } from '@angular/core';
import { AlbumService } from './album.service';
import { ApidiscotecaService } from './apidiscoteca.service';
import { Album } from './album';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';
  strArtista: string;
  strAlbum: string;
  album: Album;
  tracks:any[];
  message:string;
  isSearchData:boolean = true;

  constructor(
    protected userService:AlbumService,
    protected apiDiscotecaService:ApidiscotecaService
    ) {
  }

  ngOnInit() {
  }
  
  sendValues(): void {

    this.isSearchData =  this.validateSearchData();

    if (this.isSearchData) {
      this.userService.getInfoAlbum(this.strArtista,this.strAlbum).subscribe(
        (data) => {
          if (data['error']) {
            this.message = data['message'];
          } else {
            this.album = data['album'];        
            this.album.artist =  this.album['artist'];
            this.album.image = this.album['image'][3]['#text'];
            this.album.title = this.album['name'];
            this.tracks = this.album['tracks']['track'];
            this.album.songs = this.getSongs (this.tracks);
            this.album.published = this.album['wiki']['published'];
            this.album.content = this.album['wiki']['content'];
            this.album.summary = this.album['wiki']['summary'];
  
            console.log(this.album);
          }
        }
      );
    }
  }

  validateSearchData():boolean {

    let isSearchDataOk:boolean = true;
    this.message = '';

    if (!this.strArtista) {
      this.message = 'Debe indicar algún criterio de búsqueda';
      isSearchDataOk = false;
    } 

    return isSearchDataOk;
  }

  getSongs (dataTracks):string[] {
    
    let songs:string[] = new Array();
    let numSongs:number;
    let i:number;

    numSongs = Object.keys(this.tracks).length;

    for (i = 0;i < numSongs; i++) {
      songs.push(dataTracks[i]['name']);
    }

    return songs;
  }

  saveAlbum():void {

    this.apiDiscotecaService.postAlbum(this.album).subscribe(
      data => {
        console.log(data.message);
      },
      Error => {
        console.log(Error.message);
      });
  }
}
